The detailed processes of using the code（WEKA 3.6.7）：
1、Unzip KFDB.zip and import into Eclipse using File -> Import -> Existing Projects into Workspace
2、Add the path of your dataset folder in KFDB_CV.java
3、Run KFDB_CV.java.
